﻿// Models/Booking.cs
using Eventibles.Models;
using System.ComponentModel.DataAnnotations;

public class Booking
{
    public int BookingId { get; set; }

    [Required]
    public required string CustomerName { get; set; }

    [Required]
    [EmailAddress]
    public required string CustomerEmail { get; set; }

    [Required]
    [Range(1, 20)]
    public int NumberOfTickets { get; set; }

    public DateTime BookingDate { get; set; } = DateTime.Now;

    [Required]
    public int EventId { get; set; }

    public required Event Event { get; set; }
    public string Status { get; set; } = "Pending";
}