﻿using Microsoft.EntityFrameworkCore;

namespace Eventibles.Models
{
    [Keyless] // Important for views
    public class EventBookingDetail
    {
        public int EventId { get; set; }
        public string EventName { get; set; }
        public string Description { get; set; }
        public string ImageBlobName { get; set; }
        public string VenueName { get; set; }
        public int BookingId { get; set; }
        public DateTime BookingDate { get; set; }
        public DateTime? EventDate { get; set; }
        public TimeSpan? EventTime { get; set; }
    }
}