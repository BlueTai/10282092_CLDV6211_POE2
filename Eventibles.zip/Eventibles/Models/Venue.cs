﻿// Models/Venue.cs
using System.ComponentModel.DataAnnotations;

public class Venue
{
    internal object VenueName;

    public int VenueId { get; set; }

    [Required]
    public string Name { get; set; }

    [Required]
    public string Location { get; set; }

    [Required]
    [Range(1, int.MaxValue)]
    public int Capacity { get; set; }

    public string ImageUrl { get; set; }

    public ICollection<Event> Events { get; set; }
}