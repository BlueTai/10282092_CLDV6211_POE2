﻿// Models/Event.cs
using Eventibles.Models;
using System.ComponentModel.DataAnnotations;

public class Event
{
    public int EventId { get; set; }

    [Required]
    public string Name { get; set; }

    public string Description { get; set; }

    [Required]
    [DataType(DataType.DateTime)]
    public DateTime Date { get; set; }

    public string ImageUrl { get; set; }

    [Required]
    public int VenueId { get; set; }

    public Venue Venue { get; set; }

    public ICollection<Booking> Bookings { get; set; }
    public object EventDate { get; internal set; }
    public object EventTime { get; internal set; }
}