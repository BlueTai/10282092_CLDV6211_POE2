﻿
using Eventibles.Models;
using Microsoft.EntityFrameworkCore;

namespace Eventibles.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            if (!context.Venues.Any())
            {
                context.Venues.AddRange(
                    new Venue
                    {
                        Name = "Grand Ballroom",
                        Location = "123 Main St",
                        Capacity = 500,
                        ImageUrl = "https://images.unsplash.com/photo-1551806235-6695c9d7aa2f"
                    },
                    new Venue
                    {
                        Name = "Convention Center",
                        Location = "456 Oak Ave",
                        Capacity = 1000,
                        ImageUrl = "https://images.unsplash.com/photo-1575320181282-9afab399332c"
                    }
                );
                context.SaveChanges();
            }

            if (!context.Events.Any() && context.Venues.Any())
            {
                var venue1 = context.Venues.First();
                var venue2 = context.Venues.Skip(1).First();

                context.Events.AddRange(
                    new Event
                    {
                        Name = "Tech Conference",
                        Description = "Annual tech event",
                        Date = DateTime.Now.AddDays(30),
                        VenueId = venue1.VenueId,
                        ImageUrl = "https://images.unsplash.com/photo-1511578314322-379afb476865"
                    },
                    new Event
                    {
                        Name = "Music Festival",
                        Description = "Summer music festival",
                        Date = DateTime.Now.AddDays(60),
                        VenueId = venue2.VenueId,
                        ImageUrl = "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3"
                    }
                );
                context.SaveChanges();
            }
        }
    }
}