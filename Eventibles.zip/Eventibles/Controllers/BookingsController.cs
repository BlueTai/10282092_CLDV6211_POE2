﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Eventibles.Data;
using Eventibles.Models;
using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace Eventibles.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<BookingsController> _logger;

        public BookingsController(ApplicationDbContext context, ILogger<BookingsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Booking>>> GetBookings()
        {
            var bookings = await _context.Bookings.Include(b => b.Event).ToListAsync();
            return Ok(bookings);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Booking>> GetBooking(int id)
        {
            var booking = await _context.Bookings.Include(b => b.Event).FirstOrDefaultAsync(b => b.BookingId == id);

            if (booking == null)
            {
                return NotFound();
            }

            return Ok(booking);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutBooking(int id, Booking booking)
        {
            if (id != booking.BookingId)
            {
                return BadRequest();
            }

            _context.Entry(booking).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookingExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost]
        public async Task<ActionResult<Booking>> PostBooking(Booking booking)
        {
            // Validation: Double Booking Prevention
            // The key is to check against the database with the provided booking details
            bool isVenueBooked = await _context.Bookings.AnyAsync(
                b => b.Event.VenueId == booking.Event.VenueId &&
                     b.Event.EventDate == booking.Event.EventDate &&
                     b.Event.EventTime == booking.Event.EventTime);

            if (isVenueBooked)
            {
                return Conflict("Venue is already booked for this date and time.");
            }

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBooking", new { id = booking.BookingId }, booking);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBooking(int id)
        {
            var booking = await _context.Bookings.Include(b => b.Event).FirstOrDefaultAsync(b => b.BookingId == id); // Include Event data
            if (booking == null)
            {
                return NotFound();
            }
            await Booking(id);
            {
                return BadRequest("Cannot delete active bookings.");
            }

            _ = _context.Bookings.Remove(booking);
            await _context.SaveChangesAsync();

            return NoContent();

            async Task Booking(int id)
            {

                // Validation: Active Booking Deletion Restriction
                // Check if the event date is in the future AND the booking is not canceled
                var booking = await _context.Bookings
         .Include(b => b.Event) // Eagerly load the Event
         .FirstOrDefaultAsync(b => b.BookingId == id);
            }
        }

        private bool BookingExists(int id)
        {
            return _context.Bookings.Any(e => e.BookingId == id);
        }
    }
}
